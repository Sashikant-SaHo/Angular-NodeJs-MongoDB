

export class PeriService{

    semi(a,b,c){
    return (a+b+c)/2.0;
    }
    
    }