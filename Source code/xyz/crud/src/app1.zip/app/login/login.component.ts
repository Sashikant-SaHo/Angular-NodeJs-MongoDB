import { Component, OnInit } from '@angular/core';
import { userInfo } from 'os';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
private user : any = {};
  constructor(private router : Router) { }

  ngOnInit() {
  }

  checkLogin(){
    if(this.user.email=="mohan@gmail.com" && this.user.password=="123456"){
      console.log("Correct Login");
      this.router.navigate(['/about'])
    }
    else{
      console.log("Incorrect login")
    }
  }

}
