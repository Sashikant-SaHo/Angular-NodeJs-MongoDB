import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-dynamic2frm',
  templateUrl: './dynamic2frm.component.html',
  styleUrls: ['./dynamic2frm.component.css']
})
export class Dynamic2frmComponent implements OnInit {
private frm : FormGroup;
  constructor(private fb : FormBuilder) { }

  ngOnInit() {
this.frm = this.fb.group({
  first_name : [null,[Validators.required]],
  email : [null,[Validators.required]],
  patients : this.fb.array([
  ])
})
  }

  createPatientForm(){
    return this.fb.group({
      patient_name : [null,[Validators.required]],
      patient_disease : [null,[Validators.required]]
    })
  }

  addPatient(){
    var controls = this.frm.get('patients') as FormArray;
  controls.push(this.createPatientForm())
  }

  deletePatientForm(index){
    var controls = this.frm.get("patients") as FormArray;
    controls.removeAt(index)
  }


}
