import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { DoctorsComponent } from './doctors/doctors.component';
import {HttpModule} from '@angular/http';
import { ProductComponent } from './product/product.component';
import { CalculatorService } from './services/calculator.service';
import { TriangleService } from './services/triangle.service';
import { PeriService } from './services/peri.service';
import { TriService } from './services/tri.service';
import { PromiseService } from './services/promise.service';
import { Obs1Component } from './obs1/obs1.component';
import { Templateform1Component } from './templateform1/templateform1.component';
import { Reactiveex1Component } from './reactiveex1/reactiveex1.component';
import { Dynamicform1Component } from './dynamicform1/dynamicform1.component';
import { DoublePipe } from './pipes/double.pipe';
import { TestpipeComponent } from './testpipe/testpipe.component';
import { PowPipe } from './pipes/pow.pipe';
import { Dynamic2frmComponent } from './dynamic2frm/dynamic2frm.component';
import {RouterModule} from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { UsersComponent } from './users/users.component';
@NgModule({
  declarations: [
    AppComponent,
    EmployeesComponent,
    DoctorsComponent,
    ProductComponent,
    Obs1Component,
    Templateform1Component,
    Reactiveex1Component,
    Dynamicform1Component,
    DoublePipe,
    TestpipeComponent,
    PowPipe,
    Dynamic2frmComponent,
    AboutComponent,
    ContactComponent,
    HomeComponent,
    LoginComponent,
    UsersComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path : '',component : HomeComponent },
      {path : 'login',component : LoginComponent },
      {path : 'contact',component : ContactComponent},
      {path : 'about',component : AboutComponent},
      {path : 'users/:id1/:id2/:id3',component : UsersComponent}
    
    ])

  ],
  providers: [PromiseService,CalculatorService,TriangleService,TriService,PeriService],
  bootstrap: [AppComponent]
})
export class AppModule { }
